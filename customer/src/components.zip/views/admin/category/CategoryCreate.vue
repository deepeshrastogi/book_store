<template>
    <CreateComponent/>
</template>

<script>
import CreateComponent from '../../../components/admin/category/CreateComponent.vue';
export default {
    name:'CategoryCreate',
    components:{
        CreateComponent
    }
}
</script>