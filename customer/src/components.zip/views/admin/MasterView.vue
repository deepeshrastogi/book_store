<template>
    <div>
        <Header />
        <div id="layoutSidenav">
            <Sidebar />
            <div id="layoutSidenav_content">
                <main>
                    <router-view/>
                </main>
                <Footer/>
            </div>
        </div>
    </div>
</template>

<script>
// @ is an alias to /src
import Home from '../admin/pages/HomeView.vue';
import About from '../admin/pages/AboutView.vue';
import Header from '../../components/admin/HeaderComponent.vue';
import Sidebar from '../../components/admin/SidebarComponent.vue';
import Footer from '../../components/admin/FooterComponent.vue';

export default {
  name: 'MasterView',
  components: {
    Home,
    About,
    Header,
    Sidebar,
    Footer,
  }
}
</script>
