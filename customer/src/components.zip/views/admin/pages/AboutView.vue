<template>
  <div class="container-fluid px-4 home">
      about us page  
  </div>
</template>

<script>
// @ is an alias to /src
// import HelloWorld from '@/components/HelloWorld.vue'

export default {
  name: 'AboutView',
  components: {
    // HelloWorld
  }
}
</script>
