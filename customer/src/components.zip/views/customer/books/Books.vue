<template>
    <div class="container">
        <h3>Books</h3>
        <ListComponent/>
    </div>
</template>

<script>
import ListComponent from '../../../components/admin/category/ListComponent.vue';
export default {
    name:'CategoryList',
    components:{
        ListComponent
    }
}
</script>