<template>
    <div>
        <Header />
        <div id="layoutSidenav">
            <Sidebar />
            <div id="layoutSidenav_content">
                <main>
                    <router-view/>
                </main>
                <Footer/>
            </div>
        </div>
    </div>
</template>

<script>
// @ is an alias to /src
import Home from '../customer/pages/HomeView.vue';
import About from '../customer/pages/AboutView.vue';
import Header from '../../components/customer/HeaderComponent.vue';
import Sidebar from '../../components/customer/SidebarComponent.vue';
import Footer from '../../components/customer/FooterComponent.vue';

export default {
  name: 'MasterView',
  components: {
    Home,
    About,
    Header,
    Sidebar,
    Footer,
  }
}
</script>
