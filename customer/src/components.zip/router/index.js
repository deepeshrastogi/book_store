import { createRouter, createWebHistory } from 'vue-router';
import Home from '../views/customer/pages/HomeView.vue';
import Books from '../views/customer/books/Books.vue'
import CategoryCreate from '../views/customer/books/CategoryCreate.vue';

const routes = [
  {
    path: '/',
    name: 'home',
    component: Home
  },
  {
    path: '/books',
    name: 'category',
    component: Books,
  },
  // {
  //   path: '/category/create',
  //   name: 'category.create',
  //   component: CategoryCreate,
  // }
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router
