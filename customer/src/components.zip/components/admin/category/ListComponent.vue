<template>
    <div>
        Record
        <select v-model="no_of_record" @change="noOfRecordNeeded()">
            <option value="10">10</option>
            <option value="20">20</option>
            <option value="50">50</option>
            <option value="100">100</option>
            <option value="200">200</option>
            <option value="400">400</option>
        </select>
        <p v-if="successMessage" class="alert alert-success mt-2">
            {{ successMessage }}
        </p>
        <table class="table">
            <thead>
                <tr>
                    <th>S.No</th>
                    <th>Category</th>
                    <th>Parent Category</th>
                    <th>Active</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody v-if="this.categories.length > 0">
                <tr v-for="(category,index) in categories" :key="category.id">
                    <td>{{index+1}}</td>
                    <td>{{category.name}}</td>
                    <td>
                        <span v-if="Object.keys(category.parent_category).length">
                            {{category.parent_category.name}}
                        </span>
                        <span v-else>
                            No Parent
                        </span>
                    </td>
                    <td v-html="categoryStatusHTML(category.active)"></td>
                    <td>
                        <button title="Show" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></button>
                        &nbsp;
                        <button title="Edit" class="btn btn-primary btn-sm" @click="editCategory(category)"><i class="fa fa-pen"></i></button>&nbsp;
                        <button title="Delete" class="btn btn-danger btn-sm" @click="deleteCategory(category)"><i class="fa fa-trash"></i></button>
                    </td>
                </tr>
            </tbody>
            <tbody v-else>
                <tr><td colspan="5">Loading...</td></tr>
            </tbody>
        </table>
        <PaginationComponent :pagination="pagination" :offset="offset" @changePageNum="changePageNum"/>
    </div>
    
</template>

<script>
import axios from 'axios';
import PaginationComponent from '../../pagination/pagination.vue';
export default {
    name:'ListComponent',
    components:{
        PaginationComponent
    },
    data(){
        return {
            successMessage:'',
            no_of_record:10,
            category:{},
            categories : [],
            pagination: {
                total: 0,
                per_page: 10,
                last_page: 0,
                from: 1,
                to: 10,
                current_page: 1
            },
            offset:10,
            apiUrl: process.env.VUE_APP_API_URL,
        }
    },
    created(){
        this.successMessage = this.$route.query.message;
        setTimeout(() => {
            this.successMessage = '';
        }, 4000);
    },
    mounted(){
        this.getCategories();
    },
    
    methods:{
        categoryStatusHTML(active){
            return (active == 1) ? `<span class="btn btn-success">Active</span>`:`<span class="btn btn-danger btn-sm">Inactive</span>`;
        },
        getCategories(){
            axios.get(`${this.apiUrl}/category`,{
                params: {
                    page: this.pagination.current_page,
                    per_page: this.pagination.per_page
                }
            }).then(res => {
                this.categories = res.data.data.data;
                this.pagination.from = res.data.data.from;
                this.pagination.to = res.data.data.last_page;
                this.pagination.last_page = res.data.data.last_page;
            });
        },
        editCategory(category){
            this.category = category;
        },
        deleteCategory(category){

        },
        changePageNum(page){
            this.pagination.current_page = page;
            this.getCategories();
        },
        noOfRecordNeeded(){
            this.pagination.per_page = this.no_of_record;
            this.getCategories();
        }
    }
}
</script>

<style>

</style>