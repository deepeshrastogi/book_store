<template>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-12">
                <div class="card shadow-lg border-0 rounded-lg mt-5">
                    <div class="card-header"><h3 class="font-weight-light my-4">Create Category</h3></div>
                    <div class="card-body">
                        <!-- <VeeForm v-slot="{ submitCategoryForm }" :validation-schema="schema" as="div"> -->
                        <form @submit.prevent="submitCategoryForm">
                            <!-- <p v-if="errors.length">
                                <b>Please fill in all the fields</b>
                                <ul>
                                  <li v-for="error in errors" :key="error" class="alert alert-danger">{{ error }}</li>
                                </ul>
                              </p> -->
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <div class="form-floating mb-3 mb-md-0">
                                        <!-- <Field class="form-control" id="inputFirstName" name="name" type="text" placeholder="" v-model="categoryForm.name"   v-validate="'required'"/> -->
                                        <input class="form-control" id="inputFirstName" name="name" type="text" placeholder="" v-model="categoryForm.name"   v-validate="'required'"/>
                                        <label for="inputFirstName">Category</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <select class="form-control" v-model="categoryForm.parent_id">
                                            <option value="0">No Parent</option>
                                            <option v-for="parentCat in parentCategory" :key="parentCat.category_id" :value="parentCat.category_id">{{parentCat.name}}</option>
                                        </select>
                                        <label for="inputLastName">Parent Category</label>
                                    </div>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <div class="form-floating mb-3 mb-md-0">
                                        <select class="form-control" v-model="categoryForm.active" >
                                            <option value="1">Active</option>
                                            <option value="0">Inactive</option>
                                        </select>
                                        <label for="inputPassword">Is Active</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating mb-3 mb-md-0">
                                        <textarea class="form-control" v-model="categoryForm.details" ></textarea>
                                        <label for="inputPassword">Details</label>
                                    </div>
                                </div>
                                <div class="col-md-2 mt-3">
                                    <div class="d-grid"><button type="submit" class="btn btn-primary">Submit</button></div>
                                </div>
                            </div>
                        </form>
                        <!-- </VeeForm> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import axios from 'axios';
// import { Form as VeeForm, Field } from "vee-validate";
// import * as yup from "yup";

export default {
    name:'CreateComponent',
    props:{
        category:Object,
    },
    components: {
        // VeeForm,
        // Field,
    },
    data(){
        // const schema = yup.object().shape({
        //     // email: yup.string().required().email(),
        //     name: yup.string().required(),
        //     // password: yup.string().required().min(8),
        // });
        return {
            categoryForm: {
                name:'',
                parent_id:'',
                active:'',
                details:'',
            },
            parentCategory:{},
            errorMessage: "",
            successMessage: "",
            errors:[],
            // schema:this.schema,
        }
    },
    created(){
        this.getCategoryNameList();
    },
    methods:{
        submitCategoryForm(){
            let formData = this.categoryForm;
            axios.post('http://localhost:8081/api/category',formData).then(res => {
                if(res.data.error){
                    this.errorMessage = res.data.message;
                }else{
                    this.users = res.data.data;
                }
            console.log("test",res.data);
            });
            
        },
        getCategoryNameList(){
            axios.get('http://localhost:8081/api/category/name').then(res => {
               this.parentCategory = res.data.data;
            });
        },
        checkForm: function (e) {
            this.errors = [];
            if (!this.categoryForm.name) {
                // this.errors.push("Category name field is required.");
                this.errors.push({name:'Category name field is required.'});
            }
            if (!this.categoryForm.active) {
                this.errors.push("Active status field is required");
            }
            if (!this.errors.length) {
                return true;
            }
        },
    }
}
</script>

<style>
.error{
    color:red
}
</style>