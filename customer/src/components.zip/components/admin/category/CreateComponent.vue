<template>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-12">
                <div class="card shadow-lg border-0 rounded-lg mt-5">
                    <div class="card-header"><h3 class="font-weight-light my-4">Create Category</h3></div>
                    <div class="card-body">
                        <!-- <VeeForm v-slot="{ submitCategoryForm }" :validation-schema="schema" as="div"> -->
                        <form @submit.prevent="submitCategoryForm">
                            <!-- <p v-if="errors.length">
                                <b>Please fill in all the fields</b>
                                <ul>
                                  <li v-for="error in errors" :key="error" class="alert alert-danger">{{ error }}</li>
                                </ul>
                              </p> -->
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <div class="form-floating mb-3 mb-md-0">
                                        <!-- <Field class="form-control" id="inputFirstName" name="name" type="text" placeholder="" v-model="categoryForm.name"   v-validate="'required'"/> -->
                                        <input class="form-control" id="inputFirstName" name="name" type="text" placeholder="" v-model="categoryForm.name"   v-validate="'required'"/>
                                        <span v-if="formErrors['name']" class="error text-danger">{{ formErrors['name'][0] }}</span>
                                        <label for="inputFirstName">Category</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <select class="form-control" v-model="categoryForm.parent_id">
                                            <option value="0">No Parent</option>
                                            <option v-for="parentCat in parentCategory" :key="parentCat.category_id" :value="parentCat.category_id">{{parentCat.name}}</option>
                                        </select>
                                        <label for="inputLastName">Parent Category</label>
                                    </div>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <div class="form-floating mb-3 mb-md-0">
                                        <select class="form-control" v-model="categoryForm.active" name="active">
                                            <option value="1">Active</option>
                                            <option value="0">Inactive</option>
                                        </select>
                                        <span v-if="formErrors['active']" class="error text-danger">{{ formErrors['active'][0] }}</span>
                                        <label for="inputPassword">Is Active</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating mb-3 mb-md-0">
                                        <textarea class="form-control" v-model="categoryForm.details" ></textarea>
                                        <label for="inputPassword">Details</label>
                                    </div>
                                </div>
                                <div class="col-md-2 mt-3">
                                    <div class="d-grid"><button type="submit" class="btn btn-primary">Submit</button></div>
                                </div>
                            </div>
                        </form>
                        <!-- </VeeForm> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import axios from 'axios';

export default {
    name:'CreateComponent',
    props:{
        category:Object,
    },
    data(){
        return {
            categoryForm: {
                name:'',
                parent_id:'',
                active:'',
                details:'',
            },
            parentCategory:{},
            errorMessage: "",
            successMessage: "",
            formErrors:[],
            errors:[],
        }
    },
    created(){
        this.getCategoryNameList();
    },
    methods:{
        submitCategoryForm(){
            let validate = this.checkForm();
            if(validate){
                let formData = this.categoryForm;
                axios.post('http://localhost:8081/api/category',formData).then(res => {
                    if(!this.isObjectEmpty(res.data.error)){
                        this.formErrors = res.data.error;
                    }else{
                        // this.users = res.data.data;
                        console.log("a",this.$router.push({ name: 'category', query: { message: res.data.message } }));
                        this.$router.push({ name: 'category', query: { message: res.data.message } });
                    }
                });
            }else{
                this.formErrors = this.errors;
            }
        },
        getCategoryNameList(){
            axios.get('http://localhost:8081/api/category/name').then(res => {
               this.parentCategory = res.data.data;
            });
        },
        checkForm: function (e) {
            this.errors = {
                name: [],
                active: []
            };
            if (!this.categoryForm.name) {
                this.errors.name.push('Category name field is required.');
            }else{
                delete this.errors.name;
            }
            if (!this.categoryForm.active) {
                this.errors.active.push('The active field is required.');
            }else{
                delete this.errors.active;
            }
            return this.isObjectEmpty(this.errors);
        },
        isObjectEmpty(obj) {
            return Object.keys(obj).length === 0;
        }
    }
}
</script>

<style>
.error{
    color:red
}
</style>